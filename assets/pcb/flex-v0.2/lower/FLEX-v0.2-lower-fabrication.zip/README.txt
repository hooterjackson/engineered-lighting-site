Engineered Lighting FLEX v0.2 / led-lower-v0.2
Board SHA-256: 21db9dba94c6b4fd992e7c361f79d360b84270ea8c3a89099156e5972f7d6379

Manufacturing outputs generated from the design published beside them: Gerber artwork,
drill data where the design has holes, and the drill maps. F.Mask and B.Mask designate
COVERLAY OPENINGS on a flex circuit, not liquid solder mask.

This is a reference for reading the circuit, not a fabrication release. Nothing here has
been ordered, and no price, quantity or vendor correspondence is included.

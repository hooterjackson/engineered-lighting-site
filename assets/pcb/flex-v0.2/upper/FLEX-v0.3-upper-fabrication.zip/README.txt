Engineered Lighting Upper flex v0.3 / led-upper-v0.3
Board SHA-256: 0af25f8f72fb999db1bad16a8d59541a02c4eb95f838ada6dd6abadba8fe058d

Manufacturing outputs generated from the design published beside them: Gerber artwork,
drill data where the design has holes, and the drill maps. F.Mask and B.Mask designate
COVERLAY OPENINGS on a flex circuit, not liquid solder mask.

This is a reference for reading the circuit, not a fabrication release. Nothing here has
been ordered, and no price, quantity or vendor correspondence is included.

LIGHT v0.1 fabrication reference (revision c046202e)
PCB SHA-256: c046202efa3896d59d12bf19f55ed48b3a6c77532aac199a3a1e9a993e449310

These are manufacturing outputs generated from the same design source published beside them:
Gerber artwork, Excellon drill files, the job file, an IPC-D-356 netlist and the drill drawings.

They are a reference for reading the board, not a fabrication release. No quote, price, quantity or
vendor correspondence is included. The .gbrjob finish and revision fields are KiCad defaults.
Nothing here has been ordered or approved for production.

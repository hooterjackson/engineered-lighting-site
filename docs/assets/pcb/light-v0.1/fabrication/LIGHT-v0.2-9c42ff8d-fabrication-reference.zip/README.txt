LIGHT v0.2 fabrication reference (revision 9c42ff8d)
PCB SHA-256: 9c42ff8df4a3ef58ac7f16b248242f106f784dc73b5744aa6eeb2591ec120096

These are manufacturing outputs generated from the same design source published beside them:
Gerber artwork, Excellon drill files, the job file, an IPC-D-356 netlist and the drill drawings.

They are a reference for reading the board, not a fabrication release. No quote, price, quantity or
vendor correspondence is included. The .gbrjob finish and revision fields are KiCad defaults.
Submitted for quotation only; no production release.

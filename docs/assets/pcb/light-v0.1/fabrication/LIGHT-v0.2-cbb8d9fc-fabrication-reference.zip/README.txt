LIGHT v0.2 fabrication reference (revision cbb8d9fc)
PCB SHA-256: cbb8d9fc060c7f2b3e6b27b096a5728e789e816102ddba393c69e91020144abb

These are manufacturing outputs generated from the same design source published beside them:
Gerber artwork, Excellon drill files, the job file, an IPC-D-356 netlist and the drill drawings.

They are a reference for reading the board, not a fabrication release. No quote, price, quantity or
vendor correspondence is included. The .gbrjob finish and revision fields are KiCad defaults.
Submitted for quotation only; no production release.

# Project custom land patterns

The original inductor and connector reviews are retained below. The corrected board also adds `TI_RSW0010A_UQFN10_1p4x1p8_TMUXHS221F` for U17 and `SOT-23-6_FabPin1` for U18. Their exact geometry and change scope are recorded in `engineering/custom_footprint_review.md`, `engineering/rev_a_usb_layout_review.md` and `reports/hardware-correction/supervisor-footprint-equivalence.json`. U17 follows the TI RSW drawing; U18 changes only the standard footprint's triangular marker from Silk to Fab, retaining all land/mask/paste dimensions and pin numbering.

## Inductor land patterns

Created 2026-09-06 from visually inspected Bourns manufacturer drawings. These are the exact series selected by the power design; no SRN6045TA substitution is implied.

| Footprint | Primary source | Pads, mm | Nominal body, mm | Courtyard, mm |
|---|---|---|---|---|
| `L_Bourns_SRP7050TA` | [SRP7050TA.pdf](https://www.bourns.com/docs/Product-Datasheets/SRP7050TA.pdf), REV. 06/26, p1 recommended layout | Two 2.95 × 3.5 rectangles centered at (±2.725, 0). Overall span 8.4, **inner gap 2.5**. | 7.3 × 6.6; maximum height 5.0 | 8.9 × 7.4 |
| `L_Bourns_SRN6045` | [SRN6045.pdf](https://www.bourns.com/docs/Product-Datasheets/SRN6045.pdf), REV. 01/20, p1 recommended layout | Two 2 × 6 rectangles centered at (±2.15, 0). Inner gap 2.3, overall span 6.3. | 6 × 6; maximum height 4.5 | 6.8 × 6.8 |

Both sources were visually inspected in the Chrome PDF renderer through the browser tool on 2026-09-06. Revision labels were checked against manufacturer PDF text. Access did not produce a local source PDF; the links are live references, not immutable archived evidence.

The courtyard is an engineering addition, allowing at least 0.25 mm beyond the larger of maximum body tolerance and nominal copper land extents. F.Fab is a nominal bounding rectangle rather than an exact molded contour. Pad 1 is the left terminal and pad 2 the right; these inductors are electrically nonpolar. Native rectangular copper, mask and paste apertures retain the manufacturer nominal land sizes; no footprint-specific paste reduction is asserted. Assembly process, thermal performance and wetting remain manufacturing checks. SRN6045 requires the specified 250 °C maximum reflow peak; do not apply a generic 260 °C process without qualification. No unrelated 3D model is attached.

## Corrected PH2 service connector

`JST_PH_S2B-PH-SM4-TB_1x02_P2.00mm_Horizontal_JST2026` derives from the installed KiCad10 `Connector_JST:JST_PH_S2B-PH-SM4-TB_1x02-1MP_P2.00mm_Horizontal` footprint. The [JST PH catalog](https://www.jst-mfg.com/product/pdf/eng/ePH.pdf), p2 side-entry SMT layout, was visually inspected at170% on2026-09-06. The native signal-pad inner edge was 5.7 mm above the bottom retention-pad edge, exceeding the reference 5.5 mm maximum. Signal-pad centers move +0.2 mm in local y, from−2.85 to−2.65; pad size remains1×3.5 mm. This yields9 mm overall span and5.5 mm inner gap, satisfying the displayed limits. Native retention pads, body, courtyard and exact-part 3D model remain unchanged. The exact purchased header is S2B-PH-SM4-TB(LF)(SN); pad1 is left with mating direction+y. MP pads are mechanical retention, not signal contacts. Assembly tolerances remain part of normal DFM review.

## Conditional C504 capacitor pattern

`CP_CDE_AFK_CaseP_D16_H17_Provisional` is **engineering-derived and requires assembler validation before release**. The [CDE AFK manufacturer PDF](https://www.cde.com/resources/catalogs/AFK.pdf), undated seven-page edition visually accessed 2026-09-06, gives case-P dimensions on p1 and the exact AFK108M50P44T-F rating on p4, but does not publish recommended land dimensions. It therefore cannot support a claim of manufacturer-verified lands.

The proposed lands are 7.0 × 2.3 mm rectangles at (±6.5, 0), with pad 1 positive on the left and pad 2 negative on the right. They span x = ±10 mm. Derivation: terminal envelope H≤19 mm plus 0.5 mm toe allowance per end; terminal inner spacing P≈6.7 mm minus 0.35 mm heel allowance per side; maximum terminal width W=1.5 mm plus 0.4 mm lateral allowance per side. The approximate/reference dimension P does not establish production tolerance. This missing tolerance and the chosen fillets are explicit assembly review inputs, not an IPC compliance assertion. The nominal 17 mm base and maximum 17 mm height replace the earlier generic capacitor envelope. The 20.5 × 17.7 mm courtyard bounds maximum base/terminal dimensions and lands with at least 0.25 mm margin; tool/nozzle/inspection access must be reserved separately.

The manufacturer's p5 profile for this diameter permits one reflow, 230 °C peak for 5 seconds and 20 seconds at or above 200 °C. C504 must be omitted from both ordinary board reflow passes and the main stencil. The footprint therefore has **no F.Paste apertures**. Quote factory post-reflow installation using a qualified local heating/solder process and polarity inspection; these are factory operations, not user soldering. PCBWay acceptance of the pattern, process and access is a release gate. If the assembler cannot support them, replace the capacitor and recheck its electrical ratings, dimensions and lands before release. Do not silently treat this footprint or the generic Vishay-derived pattern as approved.

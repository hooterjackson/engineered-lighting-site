Engineered Lighting FLEX v0.2 / led-upper-v0.2
Board SHA-256: a5acd2a0ca0a0134b26fcce2757d164a1250080bb73f65dd778f97ea8f821d2f

Manufacturing outputs generated from the design published beside them: Gerber artwork,
drill data where the design has holes, and the drill maps. F.Mask and B.Mask designate
COVERLAY OPENINGS on a flex circuit, not liquid solder mask.

This is a reference for reading the circuit, not a fabrication release. Nothing here has
been ordered, and no price, quantity or vendor correspondence is included.

Engineered Lighting FLEX v0.2 / gimbal-static-v0.2
Board SHA-256: 7136c5c343da3194c0ada81330edd99336b3078152bb8f1ce47f5da158f2287d

Manufacturing outputs generated from the design published beside them: Gerber artwork,
drill data where the design has holes, and the drill maps. F.Mask and B.Mask designate
COVERLAY OPENINGS on a flex circuit, not liquid solder mask.

This is a reference for reading the circuit, not a fabrication release. Nothing here has
been ordered, and no price, quantity or vendor correspondence is included.
